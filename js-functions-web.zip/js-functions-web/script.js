// Shows a line of text on the web page
function print(text) {
  document.getElementById("output").innerHTML += text + "<br>";
}

// 1. Function Declaration and Calling
print("<b>1. Function Declaration</b>");

function showMessage() {
  print("Hello everyone!");
}

showMessage();
showMessage();


// 2. Local Variables
print("<b>2. Local Variables</b>");

function showLocal() {
  let message = "Hello, I'm JavaScript!"; // local variable
  print(message);
}

showLocal();


// 3. Outer Variables
print("<b>3. Outer Variables</b>");

let userName = "John";

function changeName() {
  userName = "Bob"; // changes the outer variable
  print("Hello, " + userName);
}

print(userName); // John
changeName();    // Hello, Bob
print(userName); // Bob


// 4. Parameters
print("<b>4. Parameters</b>");

function sendMessage(from, text) {
  print(from + ": " + text);
}

sendMessage("Ann", "Hello!");
sendMessage("Ann", "What's up?");
sendMessage("Ann"); // text is undefined


// 5. Default Values
print("<b>5. Default Values</b>");

function sendDefault(from, text = "no text given") {
  print(from + ": " + text);
}

sendDefault("Ann");


// 6. Returning a Value
print("<b>6. Returning a Value</b>");

function sum(a, b) {
  return a + b;
}

let result = sum(1, 2);
print(result); // 3

function checkAge(age) {
  if (age >= 18) {
    return true;
  } else {
    return false;
  }
}

print(checkAge(20)); // true
print(checkAge(15)); // false


// 7. Function Expression
print("<b>7. Function Expression</b>");

let sayHi = function () {
  print("Hello");
};

sayHi();

let func = sayHi; // copy the function
func();


// 8. Callback Functions
print("<b>8. Callback Functions</b>");

function ask(answer, yes, no) {
  if (answer == true) yes();
  else no();
}

function showOk() {
  print("You agreed.");
}

function showCancel() {
  print("You canceled the execution.");
}

ask(true, showOk, showCancel);
ask(false, showOk, showCancel);
